create PACKAGE package_country
IS
    TYPE country IS TABLE OF VARCHAR2(50)
                INDEX BY VARCHAR2(5);
END package_country

DECLARE
    t_country package_country.country;

BEGIN

  t_country('RO') := 'Romania';
  t_country('US') := 'United States of America';
  t_country('FR') := 'France';
  t_country('DE') := 'Germany';

  DBMS_Output.PUT_LINE('numarul de elemente din tablou este: ' || t_country.COUNT); --4
  t_country.DELETE('DE');
  DBMS_Output.PUT_LINE('numarul de elemente din tablou este: ' || t_country.COUNT); --3
  DBMS_Output.PUT_LINE('primul element din tablou este: ' || t_country.FIRST); --FR
  DBMS_Output.PUT_LINE('ultimul element din tablou este: ' || t_country.LAST); --US
  DBMS_Output.PUT_LINE('elementul dupa "Romania" din tablou este: ' || t_country.NEXT('RO')); --US
  DBMS_Output.PUT_LINE('elementul dinaintea "France" din tablou este: ' || t_country.PRIOR('FR')); --NULL

END;
/

